

dispatch -I name=ubuntu -- uname -a

dispatch -I name=ubuntu -s /Users/alexh/demos/rundeck/scripts/checkagain.sh -- 5 10 443

rd-queue

rd-queue kill

$ run -j adm/info


