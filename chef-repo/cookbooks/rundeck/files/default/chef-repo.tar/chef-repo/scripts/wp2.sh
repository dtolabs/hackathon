#
~/scripts/wp.sh1 monitoring 01
#
~/scripts/wp.sh1 datacollect 01
#
~/scripts/wp.sh1 database_master 01
#
~/scripts/wp.sh1 database_slave 01
#
~/scripts/wp.sh1 database_slave 02
#
~/scripts/wp.sh1 load_balancer 01
#
~/scripts/wp.sh1 webserver 01
#
~/scripts/wp.sh1 webserver 02
#
