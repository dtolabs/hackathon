ps -ef | grep knife 
