name "production"
description "Nodes in the production environment."
default_attributes(
  "app_environment" => "production"
)
