default[:rundeck][:dir] = "/var/rundeck"
default[:rundeck][:homedir] = "/home/rundeck"
